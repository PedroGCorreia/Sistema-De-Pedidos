var searchData=
[
  ['readme_2emd_0',['readme.md',['../readme_8md.html',1,'']]],
  ['remocaofila_1',['RemocaoFila',['../fila_8c.html#a486881f828c6d25b039c885f111fb4e6',1,'RemocaoFila(fila f):&#160;fila.c'],['../fila_8h.html#a486881f828c6d25b039c885f111fb4e6',1,'RemocaoFila(fila f):&#160;fila.c']]],
  ['removerinicio_2',['RemoverInicio',['../lista_8c.html#aa90d8844ec549e9b9c2702f1d1c43ba2',1,'RemoverInicio(lista *l):&#160;lista.c'],['../lista_8h.html#aa90d8844ec549e9b9c2702f1d1c43ba2',1,'RemoverInicio(lista *l):&#160;lista.c']]],
  ['retiralista_3',['RetiraLista',['../lista_8c.html#ab423f5127592121502b3cabad0b1d405',1,'RetiraLista(iterador i):&#160;lista.c'],['../lista_8h.html#ab423f5127592121502b3cabad0b1d405',1,'RetiraLista(iterador i):&#160;lista.c']]]
];
