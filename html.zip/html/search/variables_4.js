var searchData=
[
  ['igual_0',['igual',['../structlista.html#af8950fb6c06dd63f78043655e22679fe',1,'lista']]],
  ['inicio_1',['inicio',['../struct_fila.html#a73f53b0349bb995757a60c9c0bde3569',1,'Fila']]]
];
