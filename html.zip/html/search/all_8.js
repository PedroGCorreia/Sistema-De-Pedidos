var searchData=
[
  ['lista_0',['lista',['../structlista.html',1,'lista'],['../structiterador.html#a6098200949290d10afd49613a0a81e49',1,'iterador::lista()']]],
  ['lista_2ec_1',['lista.c',['../lista_8c.html',1,'']]],
  ['lista_2eh_2',['lista.h',['../lista_8h.html',1,'']]],
  ['listavazia_3',['ListaVazia',['../lista_8c.html#a317c9bfd78fe0d16dac5efca4c67302a',1,'ListaVazia(lista *l):&#160;lista.c'],['../lista_8h.html#a317c9bfd78fe0d16dac5efca4c67302a',1,'ListaVazia(lista *l):&#160;lista.c']]]
];
