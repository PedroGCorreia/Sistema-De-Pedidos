var searchData=
[
  ['igual_0',['igual',['../main_8c.html#a4755c239a7220f287cb9b03cde162ad3',1,'main.c']]],
  ['inicio_1',['Inicio',['../fila_8c.html#a5b3a3607b2a4500394b554f57a3b79ad',1,'Inicio(fila f):&#160;fila.c'],['../fila_8h.html#a5b3a3607b2a4500394b554f57a3b79ad',1,'Inicio(fila f):&#160;fila.c']]],
  ['insercaofila_2',['InsercaoFila',['../fila_8c.html#a5e817944336d5b875ec79ded419b323f',1,'InsercaoFila(fila f, T p):&#160;fila.c'],['../fila_8h.html#a5e817944336d5b875ec79ded419b323f',1,'InsercaoFila(fila f, T p):&#160;fila.c']]],
  ['inserirfim_3',['InserirFim',['../lista_8c.html#a15993037a191467df8b7b5ee8197682c',1,'InserirFim(lista *l, T p):&#160;lista.c'],['../lista_8h.html#a15993037a191467df8b7b5ee8197682c',1,'InserirFim(lista *l, T p):&#160;lista.c']]]
];
