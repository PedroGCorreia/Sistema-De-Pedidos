var searchData=
[
  ['lista_0',['lista',['../structlista.html',1,'']]]
];
