var searchData=
[
  ['quantidade_0',['quantidade',['../struct_fila.html#a8b3f7b5cf00ccf0dd445c1012b6c30c5',1,'Fila::quantidade()'],['../structlista.html#a8b3f7b5cf00ccf0dd445c1012b6c30c5',1,'lista::quantidade()']]]
];
