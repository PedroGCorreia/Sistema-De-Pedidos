var searchData=
[
  ['inicial_0',['INICIAL',['../fila_8h.html#a2c889714738551806bfe48393a669e65',1,'fila.h']]]
];
