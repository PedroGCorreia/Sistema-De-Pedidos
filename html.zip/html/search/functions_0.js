var searchData=
[
  ['adicionarlistaemandamento_0',['AdicionarListaEmAndamento',['../main_8c.html#a7cbf1ccf90260275c40e34121dff026d',1,'main.c']]],
  ['adicionarpedido_1',['AdicionarPedido',['../main_8c.html#a867de8cfb898e3ef8f5eb11dfa2236ac',1,'main.c']]]
];
