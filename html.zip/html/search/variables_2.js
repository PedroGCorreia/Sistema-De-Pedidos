var searchData=
[
  ['elemento_0',['elemento',['../structiterador.html#a2a97d32403a9e26806dc107bbf5f0de2',1,'iterador']]]
];
