var searchData=
[
  ['primeiroelemento_0',['PrimeiroElemento',['../fila_8c.html#af8e398a5308e0a44c28390359ee798a4',1,'PrimeiroElemento(fila f):&#160;fila.c'],['../fila_8h.html#af8e398a5308e0a44c28390359ee798a4',1,'PrimeiroElemento(fila f):&#160;fila.c']]],
  ['primeirolista_1',['PrimeiroLista',['../lista_8c.html#a2bc8e4e20f76d03f389574a292378e16',1,'PrimeiroLista(lista *l):&#160;lista.c'],['../lista_8h.html#a2bc8e4e20f76d03f389574a292378e16',1,'PrimeiroLista(lista *l):&#160;lista.c']]],
  ['proximolista_2',['ProximoLista',['../lista_8c.html#abafcf372e11aa2f06daa48382e73cd30',1,'ProximoLista(iterador i):&#160;lista.c'],['../lista_8h.html#abafcf372e11aa2f06daa48382e73cd30',1,'ProximoLista(iterador i):&#160;lista.c']]]
];
