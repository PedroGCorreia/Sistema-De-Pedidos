var searchData=
[
  ['node_0',['node',['../structnode.html',1,'']]],
  ['node_1',['Node',['../lista_8h.html#ac09cf950484bd9550d14d602b0e5e7fb',1,'lista.h']]],
  ['numero_2',['numero',['../structpedidos.html#a2c30f43104974e72e2809fb4569804b0',1,'pedidos']]]
];
