var searchData=
[
  ['lista_0',['lista',['../structiterador.html#a6098200949290d10afd49613a0a81e49',1,'iterador']]]
];
