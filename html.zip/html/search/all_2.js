var searchData=
[
  ['cabecalho_0',['cabecalho',['../interface_8c.html#a85ee333564419055cb2960a0d2b61c83',1,'cabecalho():&#160;interface.c'],['../interface_8h.html#a85ee333564419055cb2960a0d2b61c83',1,'cabecalho():&#160;interface.c']]],
  ['criafila_1',['CriaFila',['../fila_8c.html#a404c9672724d862da5f92dbb0823b0c2',1,'CriaFila():&#160;fila.c'],['../fila_8h.html#a404c9672724d862da5f92dbb0823b0c2',1,'CriaFila():&#160;fila.c']]],
  ['crialista_2',['CriaLista',['../lista_8c.html#a77c54a92468ed923385088aeddf0bad4',1,'CriaLista(lista *l, int(*igual)(T, T)):&#160;lista.c'],['../lista_8h.html#a77c54a92468ed923385088aeddf0bad4',1,'CriaLista(lista *l, int(*igual)(T, T)):&#160;lista.c']]]
];
