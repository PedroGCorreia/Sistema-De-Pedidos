var searchData=
[
  ['t_0',['T',['../fila_8h.html#a5bab8dcacf5011bf4c04a6f0dc3d1c7f',1,'T():&#160;fila.h'],['../lista_8h.html#a5bab8dcacf5011bf4c04a6f0dc3d1c7f',1,'T():&#160;lista.h']]]
];
