var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['marcarcomoconcluido_1',['MarcarComoConcluido',['../main_8c.html#a8e285020db871896346d5ca474e3c8bb',1,'main.c']]],
  ['mostrarpedidosconcluidos_2',['MostrarPedidosConcluidos',['../main_8c.html#ac7f0482da473f1f20cc4908e021ded49',1,'main.c']]],
  ['mostrarpedidosemandamento_3',['MostrarPedidosEmAndamento',['../main_8c.html#a81e7a69502d63dee8e7a746a4c100ac2',1,'main.c']]]
];
