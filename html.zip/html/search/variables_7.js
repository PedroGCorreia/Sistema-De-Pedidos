var searchData=
[
  ['numero_0',['numero',['../structpedidos.html#a2c30f43104974e72e2809fb4569804b0',1,'pedidos']]]
];
