var searchData=
[
  ['opcoes_0',['opcoes',['../interface_8c.html#ac60c6a1c380ebb819574633786403a9e',1,'opcoes():&#160;interface.c'],['../interface_8h.html#ac60c6a1c380ebb819574633786403a9e',1,'opcoes():&#160;interface.c']]]
];
