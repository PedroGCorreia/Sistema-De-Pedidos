var searchData=
[
  ['lista_2ec_0',['lista.c',['../lista_8c.html',1,'']]],
  ['lista_2eh_1',['lista.h',['../lista_8h.html',1,'']]]
];
