var searchData=
[
  ['node_0',['Node',['../lista_8h.html#ac09cf950484bd9550d14d602b0e5e7fb',1,'lista.h']]]
];
