var searchData=
[
  ['tipo_0',['tipo',['../structpedidos.html#a02fa0e89410f32f68d8b7ee4249840ab',1,'pedidos']]]
];
