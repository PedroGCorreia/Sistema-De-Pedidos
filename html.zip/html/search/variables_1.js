var searchData=
[
  ['dados_0',['dados',['../struct_fila.html#afd1da4885364f6c6a743772a6591bb66',1,'Fila::dados()'],['../structnode.html#af4a60f8e22657c5fea2079cf735fdc00',1,'node::dados()']]]
];
