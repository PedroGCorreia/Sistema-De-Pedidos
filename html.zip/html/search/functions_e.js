var searchData=
[
  ['validolista_0',['ValidoLista',['../lista_8c.html#a5c0f78fa2013bba22346604b7add4b9d',1,'ValidoLista(iterador i):&#160;lista.c'],['../lista_8h.html#a5c0f78fa2013bba22346604b7add4b9d',1,'ValidoLista(iterador i):&#160;lista.c']]]
];
