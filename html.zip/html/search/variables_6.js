var searchData=
[
  ['max_0',['max',['../struct_fila.html#ae1e1dde676c120fa6d10f3bb2c14059e',1,'Fila']]]
];
