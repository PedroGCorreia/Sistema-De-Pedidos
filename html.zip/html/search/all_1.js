var searchData=
[
  ['buscalista_0',['BuscaLista',['../lista_8c.html#a886808693b334ad57def0f482e63ef07',1,'BuscaLista(iterador i, T p):&#160;lista.c'],['../lista_8h.html#a886808693b334ad57def0f482e63ef07',1,'BuscaLista(iterador i, T p):&#160;lista.c']]]
];
