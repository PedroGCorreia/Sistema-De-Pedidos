var searchData=
[
  ['projeto_20prático_20da_20disciplina_20de_20estrutura_20de_20dados_0',['Projeto prático da disciplina de estrutura de dados',['../md_readme.html',1,'']]]
];
