var searchData=
[
  ['igual_0',['igual',['../structlista.html#af8950fb6c06dd63f78043655e22679fe',1,'lista::igual()'],['../main_8c.html#a4755c239a7220f287cb9b03cde162ad3',1,'igual(pedido p1, pedido p2):&#160;main.c']]],
  ['inicial_1',['INICIAL',['../fila_8h.html#a2c889714738551806bfe48393a669e65',1,'fila.h']]],
  ['inicio_2',['inicio',['../struct_fila.html#a73f53b0349bb995757a60c9c0bde3569',1,'Fila']]],
  ['inicio_3',['Inicio',['../fila_8c.html#a5b3a3607b2a4500394b554f57a3b79ad',1,'Inicio(fila f):&#160;fila.c'],['../fila_8h.html#a5b3a3607b2a4500394b554f57a3b79ad',1,'Inicio(fila f):&#160;fila.c']]],
  ['insercaofila_4',['InsercaoFila',['../fila_8c.html#a5e817944336d5b875ec79ded419b323f',1,'InsercaoFila(fila f, T p):&#160;fila.c'],['../fila_8h.html#a5e817944336d5b875ec79ded419b323f',1,'InsercaoFila(fila f, T p):&#160;fila.c']]],
  ['inserirfim_5',['InserirFim',['../lista_8c.html#a15993037a191467df8b7b5ee8197682c',1,'InserirFim(lista *l, T p):&#160;lista.c'],['../lista_8h.html#a15993037a191467df8b7b5ee8197682c',1,'InserirFim(lista *l, T p):&#160;lista.c']]],
  ['interface_2ec_6',['interface.c',['../interface_8c.html',1,'']]],
  ['interface_2eh_7',['interface.h',['../interface_8h.html',1,'']]],
  ['iterador_8',['iterador',['../structiterador.html',1,'']]]
];
