var searchData=
[
  ['t_0',['T',['../fila_8h.html#a5bab8dcacf5011bf4c04a6f0dc3d1c7f',1,'T():&#160;fila.h'],['../lista_8h.html#a5bab8dcacf5011bf4c04a6f0dc3d1c7f',1,'T():&#160;lista.h']]],
  ['tamanhofila_1',['TamanhoFila',['../fila_8c.html#a072f0034c7240b93894c03564bf8ecc3',1,'TamanhoFila(fila f):&#160;fila.c'],['../fila_8h.html#a072f0034c7240b93894c03564bf8ecc3',1,'TamanhoFila(fila f):&#160;fila.c']]],
  ['tamanholista_2',['TamanhoLista',['../lista_8c.html#aead99019b6a07f271e1b9b53488dc5b2',1,'TamanhoLista(lista *l):&#160;lista.c'],['../lista_8h.html#aead99019b6a07f271e1b9b53488dc5b2',1,'TamanhoLista(lista *l):&#160;lista.c']]],
  ['tipo_3',['tipo',['../structpedidos.html#a02fa0e89410f32f68d8b7ee4249840ab',1,'pedidos']]]
];
