var searchData=
[
  ['tamanhofila_0',['TamanhoFila',['../fila_8c.html#a072f0034c7240b93894c03564bf8ecc3',1,'TamanhoFila(fila f):&#160;fila.c'],['../fila_8h.html#a072f0034c7240b93894c03564bf8ecc3',1,'TamanhoFila(fila f):&#160;fila.c']]],
  ['tamanholista_1',['TamanhoLista',['../lista_8c.html#aead99019b6a07f271e1b9b53488dc5b2',1,'TamanhoLista(lista *l):&#160;lista.c'],['../lista_8h.html#aead99019b6a07f271e1b9b53488dc5b2',1,'TamanhoLista(lista *l):&#160;lista.c']]]
];
