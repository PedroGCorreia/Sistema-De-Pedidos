var searchData=
[
  ['valor_0',['valor',['../structpedidos.html#a2f40aca023a28e5cf57a29305102fdba',1,'pedidos']]]
];
