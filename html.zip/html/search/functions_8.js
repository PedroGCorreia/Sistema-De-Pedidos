var searchData=
[
  ['listavazia_0',['ListaVazia',['../lista_8c.html#a317c9bfd78fe0d16dac5efca4c67302a',1,'ListaVazia(lista *l):&#160;lista.c'],['../lista_8h.html#a317c9bfd78fe0d16dac5efca4c67302a',1,'ListaVazia(lista *l):&#160;lista.c']]]
];
